# Data for analysis



## Diabetes data from Kaggle

https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database?resource=download

## Other datasets from the ISLP package and book

https://www.statlearning.com/

## Dragon data

Created using the script `dragon_data.py`

`cancer_data_load_save_NC160.py` loads the NCI60 cancer data from a GitHub repository and saves it as a CSV file.

`cancer_data_saved_NC160.csv` is the saved cancer data.